from frappe import _

def get_data():
	return [
		{
			"module_name": "Sadbhavna Donatekart",
			"type": "module",
			"label": _("Sadbhavna Donatekart")
		}
	]
