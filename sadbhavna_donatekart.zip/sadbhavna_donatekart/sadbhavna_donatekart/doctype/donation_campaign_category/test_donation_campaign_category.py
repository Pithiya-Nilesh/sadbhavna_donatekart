# Copyright (c) 2023, Sanskar and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestDonationCampaignCategory(FrappeTestCase):
	pass
