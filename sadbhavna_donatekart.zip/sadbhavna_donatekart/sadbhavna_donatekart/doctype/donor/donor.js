// Copyright (c) 2023, Sanskar and contributors
// For license information, please see license.txt

frappe.ui.form.on('Donor', {
	// refresh: function(frm) {

	// }
});
